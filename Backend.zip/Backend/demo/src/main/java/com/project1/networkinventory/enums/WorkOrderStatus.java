package com.project1.networkinventory.enums;

public enum WorkOrderStatus {
    SCHEDULED,
    IN_PROGRESS,
    COMPLETED,
    FAILED,
    CANCELLED
}
