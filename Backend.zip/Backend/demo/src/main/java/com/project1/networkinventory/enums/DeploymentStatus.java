package com.project1.networkinventory.enums;

public enum DeploymentStatus {
    Scheduled, InProgress, Completed, Failed
}
