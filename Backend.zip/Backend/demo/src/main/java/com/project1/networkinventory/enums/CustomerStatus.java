package com.project1.networkinventory.enums;

public enum CustomerStatus {
    Active, Inactive, Pending
}
