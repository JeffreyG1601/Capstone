package com.project1.networkinventory.enums;

public enum ConnectionType {
    Wired, Wireless
}
