package com.project1.networkinventory.enums;

public enum Role {
    Planner, Technician, Admin, SupportAgent
}
