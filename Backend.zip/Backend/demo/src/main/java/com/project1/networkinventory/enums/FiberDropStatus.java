package com.project1.networkinventory.enums;

public enum FiberDropStatus {
    Active,
    Disconnected
}
