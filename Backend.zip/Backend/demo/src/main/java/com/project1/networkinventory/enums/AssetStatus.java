package com.project1.networkinventory.enums;

public enum AssetStatus {
    Available, Assigned, Faulty, Retired
}
